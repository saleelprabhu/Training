import React from 'react';

const NotFound = () => (
    <div className="m-4">
        <b className="text-danger">404!- Page Not Found</b>
    </div>
);

export default NotFound;